package co.edu.unbosque.util;

public class MissingValueException extends Exception{

	public MissingValueException() {
		super("Error, este campo no se puede dejar vacio");
	}
	
	//Metodo que va en el controller
	public static void verificarVacio(String texto) throws MissingValueException {
		if (texto.equals("")) {
			throw new MissingValueException();
		}
	}
}
