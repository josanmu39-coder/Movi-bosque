package co.edu.unbosque.util;

public class NegativeNumberException extends Exception {
	public NegativeNumberException() {
		super("Error, el numero es negativo");
	}

	// Metodos que va en el controller
	public static void verificarNumero(int numero) throws NegativeNumberException {
		if (numero < 0) {
			throw new NegativeNumberException();
		}
	}

	public static void verificarNumero(long numero) throws NegativeNumberException {
		if (numero < 0) {
			throw new NegativeNumberException();
		}
	}

	public static void verificarNumero(short numero) throws NegativeNumberException {
		if (numero < 0) {
			throw new NegativeNumberException();
		}
	}
}
