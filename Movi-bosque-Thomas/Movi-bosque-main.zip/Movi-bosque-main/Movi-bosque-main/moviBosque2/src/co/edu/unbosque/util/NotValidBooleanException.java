package co.edu.unbosque.util;

public class NotValidBooleanException extends Exception{

	public NotValidBooleanException() {
		super("Error, la respuesta tiene que ser unicamente un: si/no");
	}
	
	//Metodo que va en el controller
	public static void verificarBooleano(String texto) throws NotValidBooleanException {
	    String respuesta = texto.toLowerCase();
	    
	    if (!respuesta.equals("si") && !respuesta.equals("no")) {
	        throw new NotValidBooleanException();
	    }
	}
}
