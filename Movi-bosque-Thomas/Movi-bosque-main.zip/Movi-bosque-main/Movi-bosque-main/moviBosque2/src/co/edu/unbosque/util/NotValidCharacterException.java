package co.edu.unbosque.util;

public class NotValidCharacterException extends Exception{

	public NotValidCharacterException() {
		super("Error, caracter ingresado no valido");
	}

	//Metodo que va en el controller
	public static void verificarCaracteresEspeciales(String texto) throws NotValidCharacterException {
	    String simbolos = "?¿@;:+!$%&/()=<>.,-*^#";
	    for (int i = 0; i < simbolos.length(); i++) {
	        char s = simbolos.charAt(i);
	        if (texto.indexOf(s) != -1) {
	            throw new NotValidCharacterException();
	        }
	    }
	}

}
