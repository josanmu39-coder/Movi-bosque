package co.edu.unbosque.util;

public class NotValidSpaceException extends Exception{
	
	public NotValidSpaceException() {
		super("Error, no se permite poner espacios");
	}

	//Metodo que va en el controller
	public static void verificarEspacios(String texto) throws NotValidSpaceException {
		if (texto.contains(" ")) {
			throw new NotValidSpaceException();
		}
	}	
	
}
