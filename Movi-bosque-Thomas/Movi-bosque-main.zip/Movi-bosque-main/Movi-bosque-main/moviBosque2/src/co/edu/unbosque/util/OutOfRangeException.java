package co.edu.unbosque.util;

public class OutOfRangeException extends Exception{

	public OutOfRangeException() {
		super("El numero esta fuera del rango permitido");
	}
	
	//Metodos que va en el Controller
	public static void verificarRangoNumero(int numero) throws OutOfRangeException {
		if (numero < Integer.MIN_VALUE || numero > Integer.MAX_VALUE) {
			throw new OutOfRangeException();
		}
	}
	public static void verificarRangoNumero(long numero) throws OutOfRangeException {
		if (numero < Long.MIN_VALUE || numero > Long.MAX_VALUE) {
			throw new OutOfRangeException();
		}
	}
	public static void verificarRangoNumero(short numero) throws OutOfRangeException {
		if (numero < Short.MIN_VALUE || numero > Short.MAX_VALUE) {
			throw new OutOfRangeException();
		}
	}
}
