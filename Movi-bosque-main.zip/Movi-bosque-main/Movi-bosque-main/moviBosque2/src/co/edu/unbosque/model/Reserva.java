package co.edu.unbosque.model;

public class Reserva {

    private String id;
    private Persona persona;
    private Transporte transporte;
    private String horario;
    private boolean activa;

    public Reserva(String id, Persona persona, Transporte transporte, String horario, boolean activa) {
        this.id = id;
        this.persona = persona;
        this.transporte = transporte;
        this.horario = horario;
        this.activa = activa;
    }

    public String getId() {
        return id;
    }

    public Persona getPersona() {
        return persona;
    }

    public Transporte getTransporte() {
        return transporte;
    }

    public String getHorario() {
        return horario;
    }

    public boolean isActiva() {
        return activa;
    }
}