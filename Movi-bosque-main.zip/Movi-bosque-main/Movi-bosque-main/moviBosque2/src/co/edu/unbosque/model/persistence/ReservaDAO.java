package co.edu.unbosque.model.persistence;

import java.util.ArrayList;
import co.edu.unbosque.model.Reserva;

public class ReservaDAO {

    private ArrayList<Reserva> listaReservas;

    public ReservaDAO() {
        listaReservas = new ArrayList<>();
    }

    public ArrayList<Reserva> getListaReservas() {
        return listaReservas;
    }

    public void crear(Reserva reserva) {
        listaReservas.add(reserva);
    }
}